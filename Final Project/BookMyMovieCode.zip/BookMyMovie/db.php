<?php 
/*if (!session_id()) {
	# code...
	session_start();
}*/

$host="localhost";
$username="hkunta1";
$password="hkunta1";
$db_name="hkunta1";
// Create connection
$conn = new mysqli($host, $username, $password,$db_name);
// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
} else{
	
}
?>
